import DCR.*;

public class ProductImpl extends AbstractProduct {
    public void missatgeProducte() {
        System.out.println("Soc el producte A");
    }
}
