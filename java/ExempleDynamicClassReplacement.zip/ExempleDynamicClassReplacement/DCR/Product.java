package DCR;

public interface Product {
    void missatgeProducte();
}
